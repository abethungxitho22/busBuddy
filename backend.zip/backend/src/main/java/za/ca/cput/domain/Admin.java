package za.ca.cput.domain;

public class Admin extends User{
}

package za.ca.cput.factory;

public class StudentFactory {
}

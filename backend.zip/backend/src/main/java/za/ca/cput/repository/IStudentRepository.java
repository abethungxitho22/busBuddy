package za.ca.cput.repository;

public interface IStudentRepository {
}

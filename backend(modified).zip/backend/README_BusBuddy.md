# BusBuddy Backend (Spring Boot)

Implements APIs for **Login** and **Routes & Schedules**.

## Endpoints

- `POST /api/login` — body: `{ "emailOrStudentId": "student1@cput.ac.za", "password": "password123" }`
- `GET /api/routes` — returns all routes
- `GET /api/schedules/{routeId}` — returns schedules for route A/B/C

## Run

```bash
mvn spring-boot:run
```
or open in IntelliJ and run `BusBuddyApplication`.

> This demo uses in-memory data. Replace `InMemoryDataService` with a real repository when ready.

package za.ca.cput.domain;

public class Student extends User{
}

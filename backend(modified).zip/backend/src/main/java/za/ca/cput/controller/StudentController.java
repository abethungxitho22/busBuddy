package za.ca.cput.controller;

public class StudentController {
}

package za.ca.cput.domain;

abstract class User {
}

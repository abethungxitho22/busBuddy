package com.busbuddy.api;
//maybe move this to other folder
import org.springframework.context.annotation.Configuration;

@Configuration
public class BusBuddyApplication {
    // Converted from @SpringBootApplication to @Configuration
    // No main method here, acts only as configuration if needed.
}

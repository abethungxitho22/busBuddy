package com.busbuddy.api.controller;
//maybe move this to other folder
import com.busbuddy.api.model.Schedule;
import com.busbuddy.api.service.InMemoryDataService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
public class SchedulesController {
    private final InMemoryDataService data;

    public SchedulesController(InMemoryDataService data) {
        this.data = data;
    }

    @GetMapping("/schedules/{routeId}")
    public List<Schedule> getSchedules(@PathVariable String routeId) {
        return data.getSchedulesByRoute(routeId);
    }
}

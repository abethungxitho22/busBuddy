package com.busbuddy.api.service;

import com.busbuddy.api.model.Route;
import com.busbuddy.api.model.Schedule;
import com.busbuddy.api.model.User;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class InMemoryDataService {
    private final Map<String, User> users = new HashMap<>();
    private final List<Route> routes = new ArrayList<>();
    private final List<Schedule> schedules = new ArrayList<>();

    public InMemoryDataService() {
        // Seed users
        users.put("student1", new User("1", "Student One", "student1@cput.ac.za", "password123"));
        users.put("10012345", new User("2", "Student Two", "10012345", "pass123")); // studentId-like login

        // Seed routes
        routes.add(new Route("A", "Route A"));
        routes.add(new Route("B", "Route B"));
        routes.add(new Route("C", "Route C"));

        // Seed schedules
        schedules.add(new Schedule("A", "07:30 AM", "Campus", "Bellville"));
        schedules.add(new Schedule("A", "08:30 AM", "Bellville", "Campus"));
        schedules.add(new Schedule("B", "09:30 AM", "Campus", "Town"));
    }

    public Optional<User> findUserByEmailOrId(String key) {
        // allow email or studentId style keys
        return users.values().stream()
                .filter(u -> u.getEmail().equalsIgnoreCase(key) || u.getEmail().equalsIgnoreCase(key) || u.getName().equalsIgnoreCase(key) || u.getId().equalsIgnoreCase(key) || (u.getEmail().indexOf('@')<0 && u.getEmail().equalsIgnoreCase(key)))
                .findFirst();
    }

    public Collection<Route> getRoutes() { return routes; }

    public List<Schedule> getSchedulesByRoute(String routeId) {
        List<Schedule> out = new ArrayList<>();
        for (Schedule s: schedules) {
            if (s.getRouteId().equalsIgnoreCase(routeId)) out.add(s);
        }
        return out;
    }
}

package com.busbuddy.api.model;
//maybe move this to other folder
public class Schedule {
    private String routeId;
    private String time;
    private String departure;
    private String arrival;

    public Schedule() { }
    public Schedule(String routeId, String time, String departure, String arrival) {
        this.routeId = routeId;
        this.time = time;
        this.departure = departure;
        this.arrival = arrival;
    }

    public String getRouteId() { return routeId; }
    public void setRouteId(String routeId) { this.routeId = routeId; }
    public String getTime() { return time; }
    public void setTime(String time) { this.time = time; }
    public String getDeparture() { return departure; }
    public void setDeparture(String departure) { this.departure = departure; }
    public String getArrival() { return arrival; }
    public void setArrival(String arrival) { this.arrival = arrival; }
}

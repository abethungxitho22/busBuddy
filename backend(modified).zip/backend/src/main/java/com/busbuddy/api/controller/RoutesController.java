package com.busbuddy.api.controller;
//maybe move this to other folder
import com.busbuddy.api.model.Route;
import com.busbuddy.api.service.InMemoryDataService;
import org.springframework.web.bind.annotation.*;

import java.util.Collection;

@RestController
@RequestMapping("/api")
public class RoutesController {
    private final InMemoryDataService data;

    public RoutesController(InMemoryDataService data) {
        this.data = data;
    }

    @GetMapping("/routes")
    public Collection<Route> getRoutes() {
        return data.getRoutes();
    }
}

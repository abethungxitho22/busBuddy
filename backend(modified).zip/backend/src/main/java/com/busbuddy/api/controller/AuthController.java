package com.busbuddy.api.controller;
//maybe move this to other folder
import com.busbuddy.api.dto.LoginRequest;
import com.busbuddy.api.dto.LoginResponse;
import com.busbuddy.api.model.User;
import com.busbuddy.api.service.InMemoryDataService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;
import java.util.Optional;
import java.util.UUID;

@RestController
@RequestMapping("/api")
public class AuthController {

    private final InMemoryDataService data;

    public AuthController(InMemoryDataService data) {
        this.data = data;
    }

    @PostMapping("/login")
    public ResponseEntity<LoginResponse> login(@Valid @RequestBody LoginRequest req) {
        Optional<User> userOpt = data.findUserByEmailOrId(req.getEmailOrStudentId());
        if (userOpt.isPresent()) {
            User u = userOpt.get();
            if (u.getPassword().equals(req.getPassword())) {
                String token = UUID.randomUUID().toString();
                return ResponseEntity.ok(new LoginResponse(true, token, u.getId(), u.getName(), u.getEmail(), "Login successful"));
            }
        }
        return ResponseEntity.status(401).body(new LoginResponse(false, null, null, null, null, "Invalid credentials"));
    }
}

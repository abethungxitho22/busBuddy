package com.busbuddy.api.dto;
//maybe move this to other folder
import jakarta.validation.constraints.NotBlank;

public class LoginRequest {
    @NotBlank
    private String emailOrStudentId;
    @NotBlank
    private String password;

    public String getEmailOrStudentId() { return emailOrStudentId; }
    public void setEmailOrStudentId(String emailOrStudentId) { this.emailOrStudentId = emailOrStudentId; }
    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }
}
